#include "mbed.h"
#include "jy901.h"
 
JY901 jy(D0, D1); //sda, scl
Serial pc(USBTX, USBRX);
 
int main() {
    float x, y, z;
    int yy,mm,dd,hh,mi,ss;
    jy.calibrateAll(50);
    while(1) {
        //x = jy.getXaxisAngle();
        //y = jy.getYaxisAngle();
        z = jy.getZaxisAngle();
        //pc.printf("x:%f | y:%f | z:%f\r\n", x, y, z);
        //printf("x:%f | y:%f | z:%f\r\n", x, y, z);
        yy=jy.getYear();
        mm=jy.getMonth();
        dd=jy.getDay();
        hh=jy.getHour();
        mi=jy.getMinute();
        ss=jy.getSecond();
        pc.printf("z:%f\r\n", z);
        pc.printf("year:%d month:%d day:%d hour:%d minute:%d second:%d\n", yy,mm,dd,hh,mi,ss);
        wait(1);
    }
}